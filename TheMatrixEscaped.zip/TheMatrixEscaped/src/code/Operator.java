package code;

public enum Operator {
DOWN,UP,RIGHT,LEFT,CARRY,TAKEPILL,KILL,FLY,DROP
}
